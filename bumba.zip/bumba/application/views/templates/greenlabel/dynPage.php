<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<div id="dynPage">
    <div class="top-bg">

    </div>
    <div class="container">
        <div class="text-content">
            <?= $content ?>
        </div>
    </div>
</div>