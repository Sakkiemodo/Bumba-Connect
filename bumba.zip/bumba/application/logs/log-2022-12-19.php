<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-12-19 03:17:15 --> 404 Page Not Found: /index
ERROR - 2022-12-19 03:22:14 --> Could not find the language line "vendor_home_page"
ERROR - 2022-12-19 03:22:26 --> Could not find the language line "vendor_home_page"
ERROR - 2022-12-19 03:24:36 --> Could not find the language line "vendor_home_page"
ERROR - 2022-12-19 03:25:06 --> 404 Page Not Found: /index
ERROR - 2022-12-19 03:25:23 --> 404 Page Not Found: /index
ERROR - 2022-12-19 03:25:28 --> 404 Page Not Found: /index
ERROR - 2022-12-19 03:25:37 --> 404 Page Not Found: /index
ERROR - 2022-12-19 03:25:42 --> 404 Page Not Found: /index
ERROR - 2022-12-19 03:29:50 --> 404 Page Not Found: /index
ERROR - 2022-12-19 03:30:00 --> 404 Page Not Found: /index
ERROR - 2022-12-19 03:30:34 --> 404 Page Not Found: /index
ERROR - 2022-12-19 03:30:56 --> 404 Page Not Found: /index
ERROR - 2022-12-19 03:33:12 --> 404 Page Not Found: ../modules/Vendor/controllers//index
ERROR - 2022-12-19 03:34:55 --> Mailer Error: SMTP connect() failed. https://github.com/PHPMailer/PHPMailer/wiki/Troubleshooting
ERROR - 2022-12-19 05:38:25 --> 404 Page Not Found: /index
ERROR - 2022-12-19 05:52:39 --> Could not find the language line "vendor_home_page"
ERROR - 2022-12-19 05:54:01 --> Could not find the language line "vendor_home_page"
ERROR - 2022-12-19 05:54:16 --> 404 Page Not Found: ../modules/Vendor/controllers//index
ERROR - 2022-12-19 05:54:31 --> 404 Page Not Found: ../modules/Vendor/controllers//index
ERROR - 2022-12-19 05:57:08 --> 404 Page Not Found: ../modules/Vendor/controllers//index
ERROR - 2022-12-19 05:58:55 --> Mailer Error: SMTP connect() failed. https://github.com/PHPMailer/PHPMailer/wiki/Troubleshooting
ERROR - 2022-12-19 05:59:38 --> Could not find the language line "vendor_home_page"
ERROR - 2022-12-19 06:00:24 --> Could not find the language line "vendor_home_page"
ERROR - 2022-12-19 06:01:14 --> Could not find the language line "vendor_home_page"
ERROR - 2022-12-19 06:03:25 --> Could not find the language line "vendor_home_page"
ERROR - 2022-12-19 06:03:36 --> Could not find the language line "vendor_home_page"
ERROR - 2022-12-19 13:59:37 --> Could not find the language line "vendor_home_page"
ERROR - 2022-12-19 19:24:13 --> 404 Page Not Found: /index
ERROR - 2022-12-19 19:24:13 --> 404 Page Not Found: /index
ERROR - 2022-12-19 22:31:39 --> 404 Page Not Found: /index
ERROR - 2022-12-19 22:44:17 --> Severity: error --> Exception: syntax error, unexpected '.' C:\wamp64\www\bumba\application\views\templates\redlabel\home.php 39
ERROR - 2022-12-19 22:44:17 --> Severity: error --> Exception: syntax error, unexpected '.' C:\wamp64\www\bumba\application\views\templates\redlabel\home.php 39
ERROR - 2022-12-19 22:44:28 --> Severity: error --> Exception: syntax error, unexpected '.' C:\wamp64\www\bumba\application\views\templates\redlabel\home.php 39
