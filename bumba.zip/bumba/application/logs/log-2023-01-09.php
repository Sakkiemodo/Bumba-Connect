<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-01-09 09:28:37 --> Image Upload Error: <p>You did not select a file to upload.</p>
