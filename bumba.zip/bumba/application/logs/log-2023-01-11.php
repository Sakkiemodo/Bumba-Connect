<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2023-01-11 10:30:11 --> Image Upload Error: <p>You did not select a file to upload.</p>
ERROR - 2023-01-11 10:30:41 --> Image Upload Error: <p>You did not select a file to upload.</p>
ERROR - 2023-01-11 10:31:04 --> Image Upload Error: <p>You did not select a file to upload.</p>
ERROR - 2023-01-11 10:31:15 --> Image Upload Error: <p>You did not select a file to upload.</p>
ERROR - 2023-01-11 10:31:23 --> Image Upload Error: <p>You did not select a file to upload.</p>
ERROR - 2023-01-11 10:31:33 --> Image Upload Error: <p>You did not select a file to upload.</p>
ERROR - 2023-01-11 10:31:43 --> Image Upload Error: <p>You did not select a file to upload.</p>
ERROR - 2023-01-11 10:31:57 --> Image Upload Error: <p>You did not select a file to upload.</p>
ERROR - 2023-01-11 10:32:06 --> Image Upload Error: <p>You did not select a file to upload.</p>
ERROR - 2023-01-11 10:32:17 --> Image Upload Error: <p>You did not select a file to upload.</p>
ERROR - 2023-01-11 10:32:31 --> Image Upload Error: <p>You did not select a file to upload.</p>
ERROR - 2023-01-11 10:32:48 --> Image Upload Error: <p>You did not select a file to upload.</p>
ERROR - 2023-01-11 10:33:10 --> Image Upload Error: <p>You did not select a file to upload.</p>
ERROR - 2023-01-11 10:33:10 --> Image Upload Error: <p>You did not select a file to upload.</p>
ERROR - 2023-01-11 10:33:42 --> Image Upload Error: <p>You did not select a file to upload.</p>
