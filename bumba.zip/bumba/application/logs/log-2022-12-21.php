<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-12-21 15:28:50 --> Could not find the language line "vendor_home_page"
ERROR - 2022-12-21 15:29:36 --> Severity: Notice --> Undefined index: brand_id C:\wamp64\www\bumba\application\modules\vendor\models\Products_model.php 52
ERROR - 2022-12-21 15:30:03 --> Image Upload Error: <p>You did not select a file to upload.</p>
ERROR - 2022-12-21 15:30:03 --> Severity: Notice --> Undefined index: brand_id C:\wamp64\www\bumba\application\modules\vendor\models\Products_model.php 34
ERROR - 2022-12-21 15:33:42 --> Could not find the language line "vendor_home_page"
ERROR - 2022-12-21 15:33:56 --> Could not find the language line "vendor_home_page"
ERROR - 2022-12-21 15:36:26 --> Could not find the language line "vendor_home_page"
ERROR - 2022-12-21 15:36:27 --> Could not find the language line "vendor_home_page"
