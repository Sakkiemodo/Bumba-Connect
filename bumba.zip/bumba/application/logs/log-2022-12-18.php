<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-12-18 18:39:51 --> Severity: Warning --> mkdir(): File exists C:\wamp64\www\bumba\application\core\ADMIN_Controller.php 83
ERROR - 2022-12-18 18:40:14 --> 404 Page Not Found: /index
ERROR - 2022-12-18 18:40:14 --> 404 Page Not Found: /index
ERROR - 2022-12-18 19:49:34 --> 404 Page Not Found: /index
ERROR - 2022-12-18 19:55:14 --> Image Upload Error: <p>You did not select a file to upload.</p>
ERROR - 2022-12-18 19:59:12 --> 404 Page Not Found: 
ERROR - 2022-12-18 19:59:23 --> 404 Page Not Found: /index
ERROR - 2022-12-18 19:59:41 --> 404 Page Not Found: /index
ERROR - 2022-12-18 20:00:41 --> Could not find the language line "vendor_home_page"
ERROR - 2022-12-18 20:03:13 --> Could not find the language line "vendor_home_page"
ERROR - 2022-12-18 20:03:23 --> Could not find the language line "vendor_home_page"
ERROR - 2022-12-18 20:03:26 --> Could not find the language line "vendor_home_page"
ERROR - 2022-12-18 20:07:07 --> Image Upload Error: <p>The filetype you are attempting to upload is not allowed.</p>
ERROR - 2022-12-18 20:07:07 --> Severity: Notice --> Undefined index: brand_id C:\wamp64\www\bumba\application\modules\vendor\models\Products_model.php 52
ERROR - 2022-12-18 20:07:29 --> Severity: Notice --> Undefined index: brand_id C:\wamp64\www\bumba\application\modules\vendor\models\Products_model.php 34
ERROR - 2022-12-18 20:09:13 --> Mailer Error: SMTP connect() failed. https://github.com/PHPMailer/PHPMailer/wiki/Troubleshooting
ERROR - 2022-12-18 20:10:14 --> Could not find the language line "vendor_home_page"
ERROR - 2022-12-18 20:10:42 --> Could not find the language line "vendor_home_page"
ERROR - 2022-12-18 20:21:52 --> Could not find the language line "vendor_home_page"
ERROR - 2022-12-18 20:22:07 --> Could not find the language line "vendor_home_page"
ERROR - 2022-12-18 20:27:27 --> Mailer Error: SMTP connect() failed. https://github.com/PHPMailer/PHPMailer/wiki/Troubleshooting
ERROR - 2022-12-18 20:28:14 --> Could not find the language line "vendor_home_page"
ERROR - 2022-12-18 20:29:42 --> 404 Page Not Found: ../modules/Vendor/controllers//index
ERROR - 2022-12-18 20:29:47 --> 404 Page Not Found: ../modules/Vendor/controllers//index
ERROR - 2022-12-18 20:30:00 --> 404 Page Not Found: ../modules/Vendor/controllers//index
